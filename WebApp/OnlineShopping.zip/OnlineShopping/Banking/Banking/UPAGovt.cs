using System;

namespace CentralGovtAdministration
{  
    public class UPAGovtHandler
    {
        public   void PayIncomeTax()
        {
            Console.WriteLine("Income Tax is deducted 5%");
        }
        public   void PayServiceTax()
        {
            Console.WriteLine(" Service Tax is deducted 8%");
        }
        public   void PayProfessionalTax()
        {
            Console.WriteLine("Professional Tax is deducted  35%");
        }
    }
}
