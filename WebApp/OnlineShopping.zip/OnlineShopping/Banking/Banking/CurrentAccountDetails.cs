
namespace Banking{
    public class CurrentAccountDetails{
        
    }
}