

namespace Shipment

{

    public class StreetAddress
    {
        public string Street { get; set; }
        public string City { get; set; }
    }

}