

namespace Shipment
{

    public enum OrderStatus  { Pending, Shipped , Approved, Rejected}
    public enum Result {Passed, Failed}
    public enum WeekDay {Monday, Tuesday, Wednesday, Thursday, Friday,SaturDay,Sunday}

    
}